(* backtrack : Board.t -> Lexicon.t -> Path.t -> int * int -> Path.t Iter.t *)
let rec backtrack board lexicon path (i, j) =
  failwith "Unimplemented"

let find_all_paths board lexicon =
  failwith "Unimplemented"
