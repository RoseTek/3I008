type t = (int * int) list

let empty = []

let add_tile board path (i, j) =
  failwith "Unimplemented"

let rec to_string board path =
  failwith "Unimplemented"

let iter_to_words board all_paths =
  failwith "Unimplemented"
