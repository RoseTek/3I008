#! /bin/sh

jbuilder exec boggle "$@"
